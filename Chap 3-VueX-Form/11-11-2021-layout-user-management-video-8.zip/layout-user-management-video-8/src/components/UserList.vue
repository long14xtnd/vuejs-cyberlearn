<template>
  <tbody>
    <user-item></user-item>
    <user-item></user-item>
    <user-item></user-item>
    <user-item></user-item>
    <user-item></user-item>
  </tbody>
</template>

<script>
import UserItem from "./UserItem.vue";
export default {
  components: {
    UserItem,
  },
};
</script>

<style></style>
